import { createClient } from '@supabase/supabase-js';

// These are your Supabase project URL and public anon key.
// You can find these in your Supabase project's settings under "API".
const supabaseUrl = 'https://buyslafezehtyfdoepfv.supabase.co'; 
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJ1eXNsYWZlemVodHlmZG9lcGZ2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTc5NDkyMjMsImV4cCI6MjA3MzUyNTIyM30.04Aaw06F3x_5S_2Go-nNJ6re_AwMKisUB4l7_irv4DU';

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Supabase URL and anonymous key must be provided.');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
