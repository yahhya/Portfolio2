import React, { useState, FormEvent } from 'react';
import { Icon } from './Icon';
import { supabase } from '../lib/supabaseClient';

interface BookingModalProps {
  onClose: () => void;
}

export const BookingModal: React.FC<BookingModalProps> = ({ onClose }) => {
  const [projectType, setProjectType] = useState('');
  const [businessName, setBusinessName] = useState('');
  const [hasPayments, setHasPayments] = useState(false);
  const [hasBlog, setHasBlog] = useState(false);
  const [additionalInfo, setAdditionalInfo] = useState('');
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!projectType || !businessName) {
      setStatus('error');
      setErrorMessage('Please fill in Project Type and Business Name.');
      return;
    }
    setStatus('loading');
    setErrorMessage('');

    const { error } = await supabase
      .from('bookings')
      .insert({ 
          projectType,
          businessName,
          hasPayments,
          hasBlog,
          additionalInfo
       });

    if (error) {
      setStatus('error');
      setErrorMessage(error.message);
      console.error('Error inserting data:', error);
    } else {
      setStatus('success');
      setProjectType('');
      setBusinessName('');
      setHasPayments(false);
      setHasBlog(false);
      setAdditionalInfo('');
      setTimeout(() => {
        onClose();
        setStatus('idle'); // Reset for next open
      }, 2000);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="bg-slate-800/80 border border-slate-700 rounded-2xl w-full max-w-lg shadow-xl relative" onClick={(e) => e.stopPropagation()}>
        <button onClick={onClose} className="absolute top-4 right-4 text-slate-400 hover:text-white transition-all duration-300 ease-in-out transform hover:scale-110 z-10">
          <Icon name="close" className="w-6 h-6" />
        </button>

        <div className="p-8">
          {status === 'success' ? (
            <div className="text-center py-10">
              <h2 className="text-2xl font-bold text-white mb-4">Thank you!</h2>
              <p className="text-slate-400">Your request has been submitted. We'll be in touch soon.</p>
            </div>
          ) : (
            <>
              <h2 className="text-2xl font-bold text-white mb-1">Get Started for Free</h2>
              <p className="text-slate-400 mb-6">Fill out the form below and we'll get back to you.</p>

              <form onSubmit={handleSubmit} noValidate>
                <div className="space-y-4">
                  <div>
                    <label htmlFor="projectType" className="block text-sm font-medium text-slate-300 mb-1">Project Type</label>
                    <input type="text" id="projectType" value={projectType} onChange={(e) => setProjectType(e.target.value)} required className="w-full bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-cyan-500" />
                  </div>
                  <div>
                    <label htmlFor="businessName" className="block text-sm font-medium text-slate-300 mb-1">Business Name</label>
                    <input type="text" id="businessName" value={businessName} onChange={(e) => setBusinessName(e.target.value)} required className="w-full bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-cyan-500" />
                  </div>
                  
                  <div className="flex items-center gap-3 pt-2">
                    <input type="checkbox" id="hasPayments" checked={hasPayments} onChange={(e) => setHasPayments(e.target.checked)} className="h-4 w-4 rounded border-slate-600 bg-slate-700/50 text-cyan-600 focus:ring-cyan-500" />
                    <label htmlFor="hasPayments" className="text-sm font-medium text-slate-300">Does your project require payments?</label>
                  </div>

                  <div className="flex items-center gap-3">
                    <input type="checkbox" id="hasBlog" checked={hasBlog} onChange={(e) => setHasBlog(e.target.checked)} className="h-4 w-4 rounded border-slate-600 bg-slate-700/50 text-cyan-600 focus:ring-cyan-500" />
                    <label htmlFor="hasBlog" className="text-sm font-medium text-slate-300">Does your project need a blog?</label>
                  </div>

                  <div>
                    <label htmlFor="additionalInfo" className="block text-sm font-medium text-slate-300 mb-1">Additional Info</label>
                    <textarea id="additionalInfo" value={additionalInfo} onChange={(e) => setAdditionalInfo(e.target.value)} rows={4} className="w-full bg-slate-700/50 border border-slate-600 rounded-lg px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"></textarea>
                  </div>
                </div>

                {status === 'error' && <p className="mt-4 text-sm text-red-400">{errorMessage}</p>}

                <div className="mt-6">
                  <button type="submit" disabled={status === 'loading'} className="w-full bg-cyan-500 hover:bg-cyan-600 text-white font-semibold px-8 py-3 rounded-lg transition-all duration-300 ease-in-out transform hover:-translate-y-1 disabled:transform-none disabled:opacity-50 disabled:cursor-not-allowed">
                    {status === 'loading' ? 'Submitting...' : 'Submit Request'}
                  </button>
                </div>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  );
};