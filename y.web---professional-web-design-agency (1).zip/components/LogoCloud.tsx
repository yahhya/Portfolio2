import React from 'react';

// Updated logos to match the visual representation in the user's latest screenshot.
const logos = [
  { name: 'Vercel', src: 'https://cdn.simpleicons.org/vercel/9ca3af' },
  { name: 'Framer', src: 'https://cdn.simpleicons.org/framer/9ca3af' },
  { name: 'Figma', src: 'https://cdn.simpleicons.org/figma/9ca3af' },
  { name: 'Notion', src: 'https://cdn.simpleicons.org/notion/9ca3af' },
  { name: 'Shopify', src: 'https://cdn.simpleicons.org/shopify/9ca3af' },
  { name: 'Webflow', src: 'https://cdn.simpleicons.org/webflow/9ca3af' },
  { name: 'Framer', src: 'https://cdn.simpleicons.org/framer/9ca3af' },
  { name: 'Figma', src: 'https://cdn.simpleicons.org/figma/9ca3af' },
];

export const LogoCloud: React.FC = () => {
  // We duplicate the logos array to create a seamless loop.
  const extendedLogos = [...logos, ...logos];

  return (
    <section className="py-12" aria-labelledby="trusted-by-heading">
      <div className="text-center">
        <p id="trusted-by-heading" className="text-sm font-semibold text-slate-400">Trusted by teams using</p>
        <div 
          className="mt-6 relative w-full overflow-hidden"
        >
          {/* 
            This container uses flexbox to lay out the logos in a single, non-wrapping line.
            The 'animate-scroll' class applies the keyframe animation for the infinite scroll.
          */}
          <div className="flex flex-nowrap animate-scroll">
            {extendedLogos.map((logo, index) => (
              <div key={index} className="px-10 flex-shrink-0 flex items-center justify-center" aria-hidden="true">
                <img src={logo.src} alt={logo.name} className="h-8" />
              </div>
            ))}
          </div>
          {/* Gradient overlays create the fade-in/fade-out effect on the edges. */}
          <div className="absolute inset-y-0 left-0 w-1/5 bg-gradient-to-r from-[#050816] to-transparent pointer-events-none"></div>
          <div className="absolute inset-y-0 right-0 w-1/5 bg-gradient-to-l from-[#050816] to-transparent pointer-events-none"></div>
        </div>
      </div>
    </section>
  );
};
